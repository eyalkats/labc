function f = lin (x,a)
f = a(1) + a(2) * x;