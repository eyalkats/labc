classdef PasteDataDialogDataClass < handle
   properties 
       PastedData;
       PastedHeaders;
       SelectedData;
       WasApproved = 0;
   end
end